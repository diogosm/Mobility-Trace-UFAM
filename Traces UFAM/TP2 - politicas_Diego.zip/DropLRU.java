/*
 * Equipe:
 *		Diego Pinheiro
 *		Gerson Correa
 *		Fábio Martins
 *		Manderson Cruz
 *		Renato Pacheco
 *
 * Drop Least Recently Received - Elimina-se do buffer a mensagem menos
 * recentemente recebida.
 *
 * A ideia principal é utilizar uma variável tempo para cada mensagem, então
 * a que tiver o menor tempo será a mensagem a ser eliminada.
 *
 * Um hash armazena o id de cada mensagem e o tempo que ela entrou no buffer,
 * caso esta mensagem seja recebida novamente e ela ainda se encontra no
 * buffer, então atualiza-se o valor do tempo de entrada da mesma, assim,
 * garante-se que ela é a mais nova recebida.
 *
 * Função checkMessage(): verifica se a mensagem já está presente no buffer.
 *
 * Função checkSpace(): verifica se há mensagem pode entrar no buffer, se
 *
 * sim, elimina-se mensagens do buffer de acordo com a política implementada.
 * Obs. 1: Como havia mensagens em que o roteador deveria receber e não as
 * recebia, criou-se uma função para atualizar o hash de acordo com o buffer
 * atual do roteador, assim, as mensagens do hash serão iguais ao do roteador
 * atual.
 *
 * Obs. 2: Cada roteador deve ter o próprio hash para que mensagens de outros
 * não conflitem com as dos demais.
 *
 */

package routing;

import java.lang.Integer;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;

import core.Message;

class DropLRU {

	private static int time;
	private HashMap<String, Integer> hash;

	public DropLRU () {
	
		this.time = 1;
		this.hash = new HashMap<String, Integer>();
	}

	private void addOrReplace (String id) {

		this.hash.put(id, this.time++);
	}

	/*
	 * just show the id and time of the message in the current router
	 */
	private void showHash (ActiveRouter router) {
	
		int mTime;
		String id;
		Iterator it = hash.entrySet().iterator();
		Map.Entry mapEntry;

		System.out.println("Router " + router.getHost() + " - Buffer:\n");
		while (it.hasNext()) {
			mapEntry = (Map.Entry) it.next();
			mTime = Integer.parseInt(mapEntry.getValue().toString());
			id = mapEntry.getKey().toString();
			System.out.println("id " + id + " time " + mTime);
		}
	}

	private void dropMessage (String id, ActiveRouter router) {
	
		showHash(router);
		this.hash.remove(id);
		router.deleteMessage(id, true); // the true argument is what make the drop
		System.out.println("\nDrop Message " + id + " from " + router.getHost() + '\n');
	}

	/*
	 * if the message already exists, update it.
	 */
	protected boolean checkMessage (Message m) {
	
		if ( !this.hash.containsKey(m.getId()) )
			return false;

		addOrReplace(m.getId());
		return true;
	}

	/*
	 * return the id of the LRU message
	 */
	private String getLRUMessage () {
	
		int lruTime = -1, mTime;
		String lru = null;
		Iterator it = hash.entrySet().iterator();
		Map.Entry mapEntry;

		while (it.hasNext()) {
			mapEntry = (Map.Entry) it.next();
			mTime = Integer.parseInt(mapEntry.getValue().toString());
			if (mTime <= lruTime || lruTime == -1) {
				lruTime = mTime;
				lru = mapEntry.getKey().toString();
			}
		}

		return lru;
	}

	/*
	 * update hash according to HashMap messages from MessageRouter.java, because
	 * a message could be dropped by a TTL less or equal to zero or, maybe, the
	 * message could be sent to another host and it's no more in the buffer.
	 */
	private void updateHash (ActiveRouter router) {
	
		String id;
		Object objs[] = hash.keySet().toArray();

		for (Object obj: objs) {
			id = obj.toString();
			if (!router.hasMessage(id))
				this.hash.remove(id);
		}
	}

	/*
	 * it dropped some message if necessary to receive the new one in the buffer
	 */
	protected boolean checkSpace (Message m, ActiveRouter router) {
	
		int freeBuffer, messageSize = m.getSize();
		Message lru;
		String id;
	
		if (messageSize > router.getBufferSize())
			return false; /* can not fit the message in the buffer */

		updateHash(router);
		/* delete messages from the buffer until there's enough space */
		freeBuffer = router.getFreeBufferSize();
		while (freeBuffer < messageSize) {
			
			id = getLRUMessage();
			if (id == null)
				return false; // any more message could be deleted, maybe it's being sent
			lru = router.getMessage(id);
			dropMessage(id, router); /* drop message */
			freeBuffer += lru.getSize();
		}

		addOrReplace(m.getId());
		return true;
	}

}
