/*
 * Equipe:
 *		Diego Pinheiro
 *		Gerson Correa
 *		Fábio Martins
 *		Manderson Cruz
 *		Renato Pacheco
 *
 * Drop Social - Elimina-se do buffer a mensagem que tiver como valor social do
 * roteador que a enviou o menor possível. Caso haja mais de um roteador com o
 * mesmo valor, elimina-se a mensagem de maior tamanho.
 * 
 * Primeiramente, precisa-se saber quantos e quais roteadores existem na
 * simulação, para isto, a cada chamada da função init() do
 * MessagemRouter.java, em que se define o nome do roteador atual, atualiza-se
 * uma lista contendo o nome de todos os roteadores presentes na simulação.
 *
 * Iniciada a simulação, inicializa-se um hash (knownRouters) para cada
 * roteador com o nome dos roteadores presentes na simulação e o nível
 * social daquele para estes - este nível por enquanto é um valor aleatório.
 *
 * Função checkSpace(): verifica se há mensagem pode entrar no buffer, se
 * sim, elimina-se mensagens do buffer de acordo com a política implementada.
 *
 * Obs.: A lista com os roteadores presentes na simulação é comum a todos
 * os objetos da classe.
 */

package routing;

import java.lang.Double;
import java.lang.Math;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

import core.Message;
import core.DTNHost;

class DropSocial {

	/* lista dos hosts presentes na simulação */
	private static List<DTNHost> hostsList = new ArrayList<DTNHost>();
	private HashMap<DTNHost, Double> knownRouters;

	public DropSocial () {
	
		this.knownRouters = new HashMap<DTNHost, Double>();
	}

	protected void addHostToList (DTNHost host) {
		
		hostsList.add(host);
	}

	/*
	 * Para cada roteador da simulação, atribui-se um nível social entre 0 e 1.
	 * Esta função é realizada somente uma vez em cada roteador, pois o nível
	 * social é fixo durante toda a simulação.
	 */
	private void setSocialLevel (ActiveRouter router) {
	
		Iterator it = this.hostsList.iterator();
		DTNHost host;

		//System.out.println("Router da vez " + router.getHost());
		while (it.hasNext()) {
			host = (DTNHost) it.next();
			//System.out.println("host " + host);
			if (host == router.getHost()) 
				knownRouters.put(host, 1.0);
			else 
				knownRouters.put(host, Math.random());
		}
	}

	/* 
	 * retorna-se o penúltimo salto da mensagem já que o último é o roteador
	 * atual.
	 */
	private DTNHost getLastDTNHost (Message m) {
	
		if (m.getHopCount() == 0)
			return null;

		return m.getHops().get(m.getHopCount()-1);
	}

	private void showBuffer (ActiveRouter router) {
	
		int mTime;
		String id;
		Map.Entry mapEntry;

		System.out.println("Router " + router.getHost() + " - Buffer:\n");
		Message ms[] = router.getMessageCollection().toArray(new Message[0]);
		for (Message m: ms) 
			System.out.println("id " + m.getId());
	}
	
	/* Elmina-se a mensagem com menor nível social e com o maior tamanho */
	private void dropMessage(Message m, ActiveRouter router) {
	
		DTNHost lastHost;

		showBuffer(router);

		lastHost = getLastDTNHost(m);
		if (lastHost == null) return;
		router.deleteMessage(m.getId(), true);

		System.out.println("\nDrop Message " + m.getId() + " from " + router.getHost() + '\n');
	}

	/*
	 * Para cada mensagem do buffer, analisa-se qual veio do host de menor nível
	 * social e tem o maior tamanho.
	 */
	private String getLessSocialLevelMessage (ActiveRouter router) {
	
		Message mToDrop = null;
		DTNHost hostM, hostDrop;
		Collection<Message> messages = router.getMessageCollection();

		for (Message m: messages) {

			/*
			 * quando não há host, então a mensagem foi criada no atual e ainda não
			 * foi saiu do buffer 
			 */
			if (getLastDTNHost(m) == null) continue;

			if (mToDrop == null)
				mToDrop = m;
			else {
				hostM = getLastDTNHost(m);
				hostDrop = getLastDTNHost(mToDrop);
				if (knownRouters.get(hostM) <= knownRouters.get(hostDrop) &&
												m.getSize() > mToDrop.getSize())
					mToDrop = m;
			}
		}

		if (mToDrop == null) return null;
		return mToDrop.getId();
	}

	/*
	 * Verifica se o tamanho da mensagem é menor ou igual ao do buffer, caso
	 * seja aceitável, elimina-se mensagens do buffer de acordo com a política
	 * Drop Social se necessário.
	 */
	protected boolean checkSpace (Message m, ActiveRouter router) {
	
		int freeBuffer, messageSize = m.getSize();
		Message lessSocial = m;
		String id;

		/* inicializa-se os hosts com níveis sociais aleatórios */
		if (knownRouters.size() == 0) 
			setSocialLevel(router);

		if (messageSize > router.getBufferSize())
			return false; /* can not fit the message in the buffer */

		/* delete messages from the buffer until there's enough space */
		freeBuffer = router.getFreeBufferSize();
		while (freeBuffer < messageSize) {
			
			id = getLessSocialLevelMessage(router);
			/* any more message could be deleted, maybe it's being sent */
			if (id == null)
				return false; 
			lessSocial = router.getMessage(id);
			dropMessage(lessSocial, router); /* drop message */
			freeBuffer += lessSocial.getSize();
		}

		return true;
	}

}
