Equipe:
	Diego Pinheiro
	Gerson Correa
	Fábio Martins
	Manderson Cruz
	Renato Pacheco

Duas classes foram alteradas e duas foram criadas:

Classes alteradas:

	- MessageRouter.java
		Esta classe contém os atributos que cada roteador possui, então foram
		adicionado dois novos correspondentes as classes criadas: dropList e
		dropSocial. Ambos são inicializados nos construtores da	classe;

	- ActiveRouter.java
		Esta classe contém métodos que serão aplicados ao roteador atual, porém
		se alterou apenas a função de recebimento das mensagens: checkReceiving().
		Originalmente esta função verifica quatro condições: (1) se o roteador
		atual está tranferindo uma mensagem, então ele sinaliza um erro, pois só
		aceita uma conexão por vez; (2) se a mensagem já foi recebida ou chegou ao
		destino final (que é o próprio roteador neste caso), então informasse que
		a mensagem não é nova; (3) se o TTL for menor ou igual a zero e o roteador
		atual não é o destino dela, sinaliza-se um erro de TTL; (4) verifica se há
		espaço para armazenar no buffer, senão, elimina-se mensagens do buffer
		segundo alguma política até que haja espaço suficiente, caso o tamanho da
		mensagem seja menor que o do buffer. As alterações neste método ocorreram
		nas condições (2) e (4).

		Ambas as políticas implementadas verificam se a mensagem já existe no
		buffer ou se há espaço suficiente após a condição (3) de acordo com as
		classes criadas. Apenas uma política é utilizada por vez, por isto o
		código de alguma sempre estará comentado.

Classes criadas:

	- DropLRU.java
		Elimina-se do buffer a mensagem menos recentemente recebida.

		A ideia principal é utilizar uma variável tempo para cada mensagem, então
		a que tiver o menor tempo será a mensagem a ser eliminada.

		Um hash armazena o id de cada mensagem e o tempo que ela entrou no buffer,
		caso esta mensagem seja recebida novamente e ela ainda se encontrar no
		buffer, então atualiza-se o valor do tempo de entrada da mesma, assim,
		garante-se que ela é a mais nova recebida.

		Obs. 1: Como havia mensagens em que o roteador deveria receber e não as
		recebia, criou-se uma função para atualizar o hash de acordo com o buffer
		atual do roteador, assim, as mensagens do hash serão iguais ao do roteador
		atual.

		Obs. 2: Cada roteador deve ter o próprio hash para que mensagens de outros
		não conflitem com as dos demais.
		
	- DropSocial.java
		Elimina-se do buffer a mensagem que tiver como valor social do roteador que
		a enviou o menor possível. Caso haja mais de um roteador com o mesmo valor,
		elimina-se a mensagem de maior tamanho.

		Primeiramente, precisa-se saber quantos e quais roteadores existem na
		simulação, para isto, a cada chamada da função init() do
		MessageRouter.java, em que se define o nome do roteador atual, atualiza-se
		uma lista contendo o nome de todos os roteadores presentes na simulação.

		Iniciada a simulação, inicializa-se um hash (knownRouters) para cada
		roteador com o nome dos roteadores presentes na simulação e o nível
		social daquele para estes - este nível por enquanto é um valor aleatório.

		Obs.: A lista com os roteadores presentes na simulação é comum a todos
		os objetos da classe.
